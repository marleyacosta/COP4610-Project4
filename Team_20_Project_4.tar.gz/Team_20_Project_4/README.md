# COP4610-Project4

## How to compile
- In the command line type the following:
> export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:.

> sudo make reset

> rm abc test

> sudo make

## How to run
After you can run several test programs. For example this is how you would run the simple-test program.
> sudo ./simple-test.exe test
